package br.dh.meli.QABugs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QaBugsApplicationTests {

	@Test
	void contextLoads() {
	}

}
