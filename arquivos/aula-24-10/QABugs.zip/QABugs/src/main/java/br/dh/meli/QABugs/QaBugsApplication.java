package br.dh.meli.QABugs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QaBugsApplication {

	public static void main(String[] args) {
		SpringApplication.run(QaBugsApplication.class, args);
	}

}
